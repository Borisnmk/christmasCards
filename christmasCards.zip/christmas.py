template_file = open('template.txt',"r")
names_file = open('employees.txt',"r")

for i in names_file:
    cards=template_file.read

print(template_file.read)